/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.johnfe.util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author johnfe
 */
public class DBConexion {

    
  
    private DBConexion() {
        
        System.out.println();
       
    
    }
    
    public Connection cnx;
    
    private static DBConexion instancia;
    
    public static DBConexion getConexion(){
        
        if(instancia ==null){
            
            instancia= new DBConexion();
            System.out.println("se instancia");
        }else
            System.out.println("yaha sido instanciada");
        
        
        return instancia;
    
    
    
    }
    
    
    
    public Connection conectar(){
      try {
            String host= "localhost";
            String user= "root";
            String password= "1234";
            String database = "ingsoft";
            
            String driver= "com.mysql.jdbc.Driver";
            
            Class.forName(driver);
            
            cnx =  DriverManager.
                    getConnection("jdbc:mysql://"+host+":3306/"
                    +database+"?useSSL=false",user,password);
            
            System.out.println("Conexion exitosa");
            
            
        } catch (Exception ex) {
            System.out.println("Conexion no exitosa");
            System.out.println(ex);
        }
        
        return cnx;
        
    
    }
    
    
    
    
    
    
}
