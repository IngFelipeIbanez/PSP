/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.johnfe.controller.impl;

import com.johnfe.controller.dao.IPersonaDAO;
import com.johnfe.model.Persona;
import com.johnfe.util.DBConexion;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author johnfe
 */
public class PersonaImpl implements IPersonaDAO {

    @Override
    public void guardarPersona(Persona persona) {
        DBConexion conexion = DBConexion.getConexion();

        try {

            conexion.conectar().setAutoCommit(false);

            String sql = "insert into persona (nombre, apellido1, apellido2, identificacion, telefono) "
                    + "values (?,?,?,?,?)";

            PreparedStatement st = conexion.conectar().prepareStatement(sql);
            st.setString(1, persona.getNombre());
            st.setString(2,persona.getApellido1());
            st.setString(3, persona.getApellido2());
            st.setString(4, persona.getIdentificacion());
            st.setString(5, persona.getTelefono());

            st.execute();

            System.out.println("se agrego correctamente");

            conexion.conectar().commit();

        } catch (Exception ex) {

            System.out.println(ex.getMessage());
            try {
                conexion.conectar().setAutoCommit(false);
                conexion.conectar().rollback();
            } catch (SQLException ex1) {
                System.out.println(ex1.getMessage());
            }

        }

    }

}
