
import com.johnfe.controller.dao.IPersonaDAO;
import com.johnfe.controller.impl.PersonaImpl;
import com.johnfe.model.Persona;
import com.johnfe.util.DBConexion;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author johnfe
 */
public class Principal {

    public static void main(String[] args) {

        
        IPersonaDAO daoPersona= new PersonaImpl();
        
        Persona persona= new Persona();
        
        persona.setApellido1("vargas");
        persona.setApellido2("Perdomo");
        persona.setNombre("John Felipe");
        persona.setIdentificacion("886355");
        persona.setTelefono("87355d");
        
        daoPersona.guardarPersona(persona);
        
      
        

       
    }

}
